from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_session import Session
import pymysql
import uuid



app = Flask(__name__, static_folder='static')
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

DB_HOST = 'localhost'
DB_USER = 'mmueller'
DB_PASSWORD = 'rosebud560'
DB_NAME = 'kiwi_electronics'

def get_database_connection():
    return pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASSWORD, database=DB_NAME)

@app.route('/index')
def index():
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())  

    connection = get_database_connection()

    cursor = connection.cursor()
    cursor.execute("SELECT * FROM kiwi_electronics.product")
    products = cursor.fetchall()
    cursor.close()

    connection.close()

    return render_template('KiwiWebsite.html', products=products)

@app.route('/add', methods=['POST'])
def add_product_to_cart():
    if request.method == 'POST':
        product_id = request.form.get('product_id')
        if not product_id:
            flash("Product ID not found")
            return redirect(url_for('index'))
        
        account_id = session.get('account_id')
        if not account_id:
            flash("account is not logged in")
        
        connection = get_database_connection()
        cursor = connection.cursor()

        cursor.execute("SELECT * FROM kiwi_electronics.product WHERE Item_ID = %s", (product_id,))
        product = cursor.fetchone()

        if not product:
            flash("Product not found")
            cursor.close()
            connection.close()
            return redirect(url_for('index'))
        
        print("product",product)
        print("session",session)
        print("account id", account_id)
        
        cart_query = "INSERT INTO kiwi_electronics.cart (Session, Account_ID, Item_ID, Quantity, Price, Timestamp) VALUES (%s, %s, %s, %s, %s, NOW())"
        cart_params = (session['session_id'], account_id, product_id, 1, product[4])
        cursor.execute(cart_query, cart_params)

        connection.commit()
        cursor.close()
        connection.close()

        flash("Product added! YAY!")
        return redirect(url_for('index'))


@app.route('/cart')
def cart():

    return render_template('cart.html')

@app.route('/search', methods=['GET'])
def search_products():
    query = request.args.get('query', default='')
    category = request.args.get('category', default='*')
    price = request.args.get('price', default='*')

    print(f"Query: {query}, Category: {category}, Price: {price}")

    connection = get_database_connection()
    cursor = connection.cursor()

    sql_query = "SELECT * FROM kiwi_electronics.product WHERE Item_Name LIKE %s"
    params = [f"%{query}%"]

    if category and category != '*':
        sql_query += " AND Category = %s"
        params.append(category)
    if price and price != '*':
        if price == 'low':
            sql_query += " AND Price < 100"
        else:
            sql_query += " AND Price >= 100"

    print("SQL Query:", sql_query, "Parameters:", params)

    cursor.execute(sql_query, params)
    search_results = cursor.fetchall()
    cursor.close()
    connection.close()

    print("Search Results:", search_results)
    print("Number of Products:", len(search_results))

    return render_template('KiwiWebsite.html', search_results=search_results)

@app.route('/', methods=['GET', 'POST'])
def login():
    # if 'account_id' in session:
    #     return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        account_id = validate_credentials(email, password)

        if account_id is not None:
            session['account_id'] = account_id
            flash("Login successful")
            return redirect(url_for('index'))
        else:
            flash("Your email and password are not found. Please try again")
            return redirect(url_for('index'))
        
    return render_template('login.html')


def validate_credentials(email, password):
    connection = get_database_connection()
    cursor = connection.cursor()
    print(email)
    print(password)
    cursor.execute("SELECT Account_ID FROM kiwi_electronics.user_account WHERE Email = %s AND Password = %s", (email, password))
    account = cursor.fetchone()
    print(account)
    cursor.close()
    connection.close()

    if account is None:
        return None
    else:
        return account[0]

if __name__ == '__main__':
    app.run(debug=True)
